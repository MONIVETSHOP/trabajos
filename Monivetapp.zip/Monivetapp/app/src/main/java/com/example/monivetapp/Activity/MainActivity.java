package com.example.monivetapp.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.monivetapp.Api.ServiceAPI;
import com.example.monivetapp.Model.Producto;
import com.example.monivetapp.R;
import com.example.monivetapp.Util.ConnectionREST;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private ImageView huella;
    private EditText user, pass;
    private Button btnLogin;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logeo_main);

        huella = (ImageView) findViewById(R.id.huella);
        user = (EditText) findViewById(R.id.user);
        pass = (EditText) findViewById(R.id.pass);
        btnLogin = (Button) findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getText().toString().equals("monivet") && pass.getText().toString().equals("monivet123")) {

                    startActivity(new Intent(MainActivity.this, Procesos.class));
                    Toast.makeText(MainActivity.this,"Inicio de sesion satiscatoriamente",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(MainActivity.this, "usuario y/o contraseña son incorrectos", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}