package com.example.monivetapp.Activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.monivetapp.Api.ServiceAPI;
import com.example.monivetapp.Model.Producto;
import com.example.monivetapp.R;
import com.example.monivetapp.Util.ConnectionREST;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Procesos extends AppCompatActivity {

    private EditText _etResultado;
    private EditText _etCodigo;
    private EditText _etNombre;
    private EditText _etPrecio;
    private EditText _etStock;
    private Button _btnGrabar;
    private Button _btnModificar;
    private Button _btnEliminar;
    private Button btnBuscar;

    private ServiceAPI serviceAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _etCodigo = findViewById(R.id.etCodigo);
        _etNombre = findViewById(R.id.etNombre);
        _etPrecio = findViewById(R.id.etPrecio);
        _etStock = findViewById(R.id.etStock);
        _etResultado = findViewById(R.id.etResultado);
        _btnGrabar = findViewById(R.id.btnProcesar);
        _btnModificar = findViewById(R.id.btnModificar);
        _btnEliminar = findViewById(R.id.btnEliminar);
        btnBuscar = findViewById(R.id.btnBuscar);

        serviceAPI = ConnectionREST.getConnection().create(ServiceAPI.class);

        load();

        btnBuscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                encontrarProducto(_etCodigo.getText().toString());
                startActivity(new Intent(Procesos.this, Busqueda.class));
            }
        });

        _btnGrabar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Producto pObj = new Producto(
                        Integer.parseUnsignedInt(_etCodigo.getText().toString()),
                        _etNombre.getText().toString(),
                        Double.parseDouble(_etPrecio.getText().toString()),
                        Integer.parseInt(_etStock.getText().toString())
                );
                addProducto(pObj);
            }
        });

        _btnEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminarProducto(Integer.parseInt(_etCodigo.getText().toString()));
            }
        });

        _btnModificar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Producto pObj = new Producto(
                        Integer.parseInt(_etCodigo.getText().toString()),
                        _etNombre.getText().toString(),
                        Double.parseDouble(_etPrecio.getText().toString()),
                        Integer.parseInt(_etStock.getText().toString())
                );
                modifyProducto(pObj);
            }
        });
    }

    private void encontrarProducto(String id) {
        Call<Producto> call = serviceAPI.find(id);

        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                if (response.isSuccessful()) {
                    mensaje("Los datos se encontraron");
                } else {
                    mensaje("Ocurrió un error: ");
                }
            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                mensaje("Ocurrió un error: " + t.getMessage());
            }
        });
    }

    private void eliminarProducto(int id) {
        Call<Producto> call = serviceAPI.removeProducto(String.valueOf(id));
        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                if (response.isSuccessful()) {
                    mensaje("Los datos se eliminaron");
                } else {
                    mensaje("Ocurrió un error: ");
                }
            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                mensaje("Ocurrió un error: " + t.getMessage());
            }
        });
    }

    private void modifyProducto(Producto pObj) {
        Call<Producto> call = serviceAPI.modifyProducto(pObj);
        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                if (response.isSuccessful()) {
                    mensaje("Los datos se modificaron ");
                } else {
                    mensaje("Ocurrió un error: ");
                }
            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                mensaje("Ocurrió un error: " + t.getMessage());
            }
        });
    }

    public void addProducto(Producto pObj) {
        Call<Producto> call = serviceAPI.addProducto(pObj);
        call.enqueue(new Callback<Producto>() {
            @Override
            public void onResponse(Call<Producto> call, Response<Producto> response) {
                if (response.isSuccessful()) {
                    mensaje("Registro grabado satisfactoriamente!");
                } else {
                    mensaje("Ocurrió un error al grabar los datos!");
                }
            }

            @Override
            public void onFailure(Call<Producto> call, Throwable t) {
                mensaje("Ocurrió un error: " + t.getMessage());
            }
        });
    }

    public void load() {
        Call<List<Producto>> call = serviceAPI.listProduct();
        call.enqueue(new Callback<List<Producto>>() {
            @Override
            public void onResponse(Call<List<Producto>> call, Response<List<Producto>> response) {
                if (response.isSuccessful()) {
                    List<Producto> respuesta = response.body();
                    _etResultado.setText("\n\n\n\n");
                    for (Producto x : respuesta) {
                        _etResultado.append("Código:" + x.getCodProducto() +
                                " Nombre:" + x.getNomProducto() +
                                " Precio:" + x.getPreProducto() +
                                " Stock:" + x.getStkProducto() + "\n");
                        Toast.makeText(getApplicationContext(),
                                "" + x.getNomProducto(), Toast.LENGTH_LONG).show();
                        mensaje(x.getCodProducto() + "-" + x.getNomProducto());
                    }
                } else {
                    Toast.makeText(getApplicationContext(),
                            "Error", Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Producto>> call, Throwable t) {
                Toast.makeText(getApplicationContext(),
                        "Ocurrió un error: ", Toast.LENGTH_LONG).show();
            }
        });
    }

    public void mensaje(String msg) {
        AlertDialog.Builder alerta = new AlertDialog.Builder(this);
        alerta.setMessage(msg);
        alerta.show();
    }
}

