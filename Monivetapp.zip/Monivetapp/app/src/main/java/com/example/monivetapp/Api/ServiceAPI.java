package com.example.monivetapp.Api;

import com.example.monivetapp.Model.Producto;
import java.util.List;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
public interface ServiceAPI {
    @GET("ListarProductos")
    Call<List<Producto>> listProduct();

    @GET("ObtenerProducto/{id}")
    Call<Producto> find(@Path("id") String id);

    @POST("Guardar")
    Call<Producto> addProducto(@Body Producto obj);

    @PUT("producto/modificar")
    Call<Producto> modifyProducto(@Body Producto obj);

    @DELETE("producto/eliminar/{id}")
    Call<Producto> removeProducto(@Path("id") String id);
}
